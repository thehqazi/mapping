define({
	root: ({
		configText: "API Key:"
  })
});
