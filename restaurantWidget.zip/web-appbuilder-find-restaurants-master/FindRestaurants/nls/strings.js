define({
  root: ({
    _widgetLabel: "Find Restaurants",
    welcomeLine: "Hello!",
    _featureAction_RestaurantsNear: "Find Restaurants Near Here",
  }),
  "es": 1
});
