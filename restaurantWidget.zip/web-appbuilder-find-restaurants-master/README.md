# ArcGIS Web AppBuilder: Find Restaurants Widget
Web AppBuilder widget to allow user to find restaurants near a location using the Yelp API.

Video of me building this widget live: [Extending the Web AppBuilder for ArcGIS Webinar](https://youtu.be/CgLFkDogAN0?t=12m52s)

[Demo app with this widget](https://gavinr.github.io/web-appbuilder-find-restaurants/)

[![screenshot](https://i.imgur.com/exnimvy.jpg)](https://gavinr.github.io/web-appbuilder-find-restaurants/)
